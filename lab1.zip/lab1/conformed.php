<html>
<body>
 <?php 
 echo $_POST["name"]; ?><br>
Your email address is: <?php echo $_POST["email"]; 
echo $_SERVER["PHP_SELF"];
?>
</body>
</html>