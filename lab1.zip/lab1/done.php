<!DOCTYPE html>


<body>

<?php

echo var_dump($_POST);

?>

</body>
